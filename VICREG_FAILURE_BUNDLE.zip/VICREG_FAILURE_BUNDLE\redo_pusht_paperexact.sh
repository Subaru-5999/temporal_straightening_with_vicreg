#!/usr/bin/env bash
# Redo PushT ON only (straightening=aggcos1e-1) end-to-end on the B200 MIG pod,
# then eval + aggregate.
# NOTE: epochs set to 3 (paper-exact PushT is 2; this is an intentional override).

cd /workspace/arun/temporal_straightening_b200
unset CUDA_VISIBLE_DEVICES
export DATASET_DIR=/workspace/arun/data D4RL_SUPPRESS_IMPORT_ERROR=1
export MUJOCO_GL=egl PYOPENGL_PLATFORM=egl WANDB_MODE=disabled WANDB_SILENT=true
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$HOME/.mujoco/mujoco210/bin:/usr/lib/nvidia
export PYTORCH_CUDA_ALLOC_CONF=backend:cudaMallocAsync
export PLAN_SERIAL_ENV=1 OMP_NUM_THREADS=8 MKL_NUM_THREADS=8 OPENBLAS_NUM_THREADS=8 NUMEXPR_NUM_THREADS=8

ON=pusht_aggmlpcos1e-1_agg32_projchannel_dim8_hw14_sgTrue_lr1e-05
rm -rf checkpoints/test/$ON
rm -rf plan_outputs_gd/${ON}_*/ plan_outputs_gd_mpc/${ON}_*/
rm -f results/$ON.json

# pre-flight: the 45 GB MIG slice must be empty
ps -eo pid,etime,rss,cmd | grep -i python | grep -v grep    # kill -9 any stray/stopped python
nvidia-smi | sed -n '/MIG dev/,/Processes/p'                # want ~2-16 MiB used

setsid nohup bash -c 'cd /workspace/arun/temporal_straightening_b200
unset CUDA_VISIBLE_DEVICES
export DATASET_DIR=/workspace/arun/data D4RL_SUPPRESS_IMPORT_ERROR=1
export MUJOCO_GL=egl PYOPENGL_PLATFORM=egl WANDB_MODE=disabled WANDB_SILENT=true
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$HOME/.mujoco/mujoco210/bin:/usr/lib/nvidia
export PYTORCH_CUDA_ALLOC_CONF=backend:cudaMallocAsync
export PLAN_SERIAL_ENV=1 OMP_NUM_THREADS=8 MKL_NUM_THREADS=8 OPENBLAS_NUM_THREADS=8 NUMEXPR_NUM_THREADS=8
echo "=== TRAIN PushT ON (straighten=aggcos1e-1, lr 1e-5, 3 epochs) ==="
python train.py --config-name train.yaml env=pusht encoder=dino_channel \
training.straighten=aggcos1e-1 training.encoder_lr=1e-5 training.epochs=3 env.num_workers=4 \
ckpt_base_path=$PWD/checkpoints && echo "TRAIN ON DONE" || { echo "TRAIN ON FAILED"; exit 1; }
echo "=== EVAL ON (OL mode=last + MPC mode=staged, alpha=1, seeds 100/200/300) ==="
python reproduce_table1.py \
pusht_aggmlpcos1e-1_agg32_projchannel_dim8_hw14_sgTrue_lr1e-05
python summarize_run.py --all
cat results/table1_reproduction.md
echo "=== REDO PUSHT ON (3 EPOCHS) DONE ==="' > redo_pusht_paperexact.log 2>&1 < /dev/null &
echo "started; watch: tail -f redo_pusht_paperexact.log"
