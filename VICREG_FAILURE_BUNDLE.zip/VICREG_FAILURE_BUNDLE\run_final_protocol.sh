#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# run_final_protocol.sh -- THE one-shot final run.
#
# Trains the tailored objective end-to-end at the paper-exact budget, then
# runs every evaluation and writes one RESULTS.md recording all of it.
#
#   L = L_pred + 0.1*SIGReg + 0.1*L_curv(agg) + 1.0*grounding
#              + lambda_cf * cf_curv  +  lambda_as * act_sens
#
# Anchors for every hyperparameter that HAS one:
#   lambda_SIG=0.1, M=1024      LeWM sec. 3
#   lambda_curv=0.1 (agg)       Straightening App. B.6
#   stop_grad=False             LeWM sec. 3 (no stop-gradient)
#   budget 123,858 iters        Straightening App. A.3 (PushT, 2 epochs)
#   encoder_lr=1e-5             Straightening Table 3
#   ground_proprio=1.0          the completed full-budget grounded run
#   backbone_lr=null            the completed full-budget grounded run
#                               (verified equivalent to 1e-5 mid-flight)
# The ONLY unanchored knobs are the two new terms; they ride on the house
# convention lambda=0.1. Sweep them with env vars if this run disappoints:
#   CF_CURV=0.3 ACT_SENS=0.03 bash run_final_protocol.sh
#
# What it records (all under <run_dir>/final_eval/ plus results/<run>.json):
#   success rates   reproduce_table1.py, GD + GD-MPC + CEM, 3 seeds (claim 4:
#                   GD-vs-CEM on the SAME model -- CEM is included by default)
#   rollout_drift   snr / beat / drift per horizon
#   metric_align    probes / Spearman / nn-state ratio
#   jac/landscape   condition-number proxy + cost-surface figures
#   RESULTS.md      everything merged by collect_final_results.py
#
# Wall clock: ~14-16 h training (the cf rollouts add a bit over the old run)
# + ~2-3 h eval. Launch detached:
#   nohup bash run_final_protocol.sh > final_protocol.log 2>&1 &
# ---------------------------------------------------------------------------
set -euo pipefail

cd "$(dirname "$(readlink -f "$0")")"

# --- Blackwell B200 / MIG env recipe (identical to train_pusht_e2e_sigreg.sh) ---
unset CUDA_VISIBLE_DEVICES                  # MIG UUID breaks mujoco-py's int() parse
export DATASET_DIR="${DATASET_DIR:-/workspace/arun/data}"
export D4RL_SUPPRESS_IMPORT_ERROR=1
export MUJOCO_GL=egl PYOPENGL_PLATFORM=egl
export WANDB_MODE="${WANDB_MODE:-offline}"
export LD_LIBRARY_PATH="${LD_LIBRARY_PATH:-}:$HOME/.mujoco/mujoco210/bin:/usr/lib/nvidia"
export PYTORCH_CUDA_ALLOC_CONF=backend:cudaMallocAsync   # MIG NVML allocator assert
export OMP_NUM_THREADS=8 MKL_NUM_THREADS=8 OPENBLAS_NUM_THREADS=8 NUMEXPR_NUM_THREADS=8

# --- objective knobs ---
MAX_ITERS="${MAX_ITERS:-123858}"
SIGREG_COEFF="${SIGREG_COEFF:-0.1}"
STRAIGHTEN="${STRAIGHTEN:-aggcos1e-1}"
GROUND="${GROUND:-1.0}"
GROUND_DIMS="${GROUND_DIMS:-null}"          # null = all 4 dims (proven config).
                                            # [0,1] = positions-only (yaml advice,
                                            # untested at full budget).
CF_CURV="${CF_CURV:-0.1}"                   # lambda_cf  -- free knob
CF_H="${CF_H:-4}"
CF_MODE="${CF_MODE:-cos}"                   # cost space (raw tokens)
ACT_SENS="${ACT_SENS:-0.1}"                 # lambda_as  -- free knob
ACT_SENS_MARGIN="${ACT_SENS_MARGIN:-0.1}"
ENCODER_LR="${ENCODER_LR:-1e-5}"
BACKBONE_LR="${BACKBONE_LR:-null}"
CKPT_BASE="${CKPT_BASE:-$PWD/checkpoints}"
PLANNERS="${PLANNERS:-gd,gd_mpc,cem}"
SKIP_TRAIN="${SKIP_TRAIN:-0}"               # 1 = eval an existing run (set RUN_DIR)
LOG="final_protocol_train_$(date +%Y%m%d_%H%M%S).log"

echo "objective: L_pred + ${SIGREG_COEFF}*SIGReg + straighten=${STRAIGHTEN}"
echo "         + ${GROUND}*grounding(dims=${GROUND_DIMS})"
echo "         + ${CF_CURV}*cf_curv(H=${CF_H}, ${CF_MODE}) + ${ACT_SENS}*act_sens(margin=${ACT_SENS_MARGIN})"
echo "budget: ${MAX_ITERS} iters | planners: ${PLANNERS}"
echo

# --- pre-flight: the 45 GB MIG slice holds exactly one job (hard gate) ---
BUSY=""
for pat in "[t]rain.py --config-name" "[p]lan.py --config-name" "[r]eproduce_table1.py"; do
  hits=$(pgrep -af "$pat" || true)
  [ -n "$hits" ] && BUSY="${BUSY}${hits}"$'\n'
done
if [ -n "${BUSY}" ] && [ "${FORCE:-0}" != "1" ]; then
  echo "REFUSING TO START: the MIG slice already has a job." >&2
  echo "${BUSY}" >&2
  echo "Chain on its PID instead, or set FORCE=1 if you know the slice is free." >&2
  exit 1
fi

# --- 1. train ---------------------------------------------------------------
if [ "${SKIP_TRAIN}" != "1" ]; then
  python train.py --config-name train.yaml \
    env=pusht \
    encoder=dino_channel \
    training.straighten="${STRAIGHTEN}" \
    training.sigreg=True \
    training.sigreg_coeff="${SIGREG_COEFF}" \
    training.sigreg_num_proj=1024 \
    training.sigreg_apply_to=agg \
    training.stop_grad=False \
    training.freeze_backbone=False \
    training.encoder_lr="${ENCODER_LR}" \
    training.backbone_lr="${BACKBONE_LR}" \
    training.ground_proprio="${GROUND}" \
    training.ground_proprio_dims="${GROUND_DIMS}" \
    training.cf_curv="${CF_CURV}" \
    training.cf_H="${CF_H}" \
    training.cf_mode="${CF_MODE}" \
    training.act_sens="${ACT_SENS}" \
    training.act_sens_margin="${ACT_SENS_MARGIN}" \
    training.epochs=3 \
    training.max_iterations="${MAX_ITERS}" \
    env.num_workers=4 \
    ckpt_base_path="${CKPT_BASE}" \
    "$@" 2>&1 | tee "${LOG}"

  # The new terms change variant_tag (_cf1e-1_as1e-1), so this run CANNOT
  # resume or collide with any earlier objective's directory.
  RUN_DIR=$(grep -m1 -oE "${CKPT_BASE}/test/[^ ,]*" "${LOG}" || true)
  [ -z "${RUN_DIR}" ] && RUN_DIR=$(ls -dt "${CKPT_BASE}"/test/*_cf*/ 2>/dev/null | head -1 || true)
else
  RUN_DIR="${RUN_DIR:?SKIP_TRAIN=1 requires RUN_DIR=/path/to/run}"
fi
RUN_DIR="${RUN_DIR%/}"
NAME=$(basename "${RUN_DIR}")
echo
echo "RUN_DIR = ${RUN_DIR}"
[ -f "${RUN_DIR}/checkpoints/model_latest.pth" ] || {
  echo "No checkpoint in ${RUN_DIR}/checkpoints -- training did not save." >&2
  exit 1
}

# --- 2. evaluate (paper protocol, incl. CEM for the GD-vs-CEM comparison) ---
python reproduce_table1.py "${NAME}" --base "${CKPT_BASE}/test" --planners "${PLANNERS}"

# --- 3. analyses -------------------------------------------------------------
mkdir -p "${RUN_DIR}/final_eval"
python experiments/rollout_drift.py "${RUN_DIR}" \
  --json "${RUN_DIR}/final_eval/rollout_drift.json"
python experiments/metric_alignment.py "${RUN_DIR}" \
  --json "${RUN_DIR}/final_eval/metric_alignment.json"
python experiments/planning_jacobian.py "${RUN_DIR}" \
  --json "${RUN_DIR}/final_eval/planning_jacobian.json"
python experiments/planning_landscape.py "${RUN_DIR}" \
  --out "${RUN_DIR}/final_eval"

# --- 4. record ---------------------------------------------------------------
python collect_final_results.py "${RUN_DIR}"

echo
echo "DONE. Everything is in:"
echo "  ${RUN_DIR}/final_eval/RESULTS.md"
